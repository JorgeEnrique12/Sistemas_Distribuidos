#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <vector>
#include "Coordenada.h"
#include "PoligonoIrreg.h"

 using namespace std;

 int main()
 {
     srand(time(NULL));
     vector <PoligonoIrreg> v1;
     int s =  rand() % 50 + 1;
     PoligonoIrreg PoligonoIrreg1(0);
    v1.reserve(s);
     cout << "size:" << s <<endl;
     for(int i = 0; i < s; i++){
         int numVertices = rand() % 50 + 1;
         cout << "size:" << numVertices <<endl;
         PoligonoIrreg PoligonoIrreg1(numVertices);
         for(int j = 0; j < numVertices; j++){
            PoligonoIrreg1.addVertice(Coordenada(rand() + 10,rand() + 10),j);
         }
         v1[i] = PoligonoIrreg1;
     }  
    cout  << "Numero de Vertices: " << PoligonoIrreg1.getNum() <<endl; 
    return 0;
 }