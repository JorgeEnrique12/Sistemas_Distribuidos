#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <vector>
#include <math.h>
#include "Coordenada.h"
#include "PoligonoReg.h"
#include "PoligonoIrreg.h"



 using namespace std;

 int main()
 {

        PoligonoReg PoligonoReg1(5);
        PoligonoReg1.addVertices();
        PoligonoReg1.imprimeVertices();
        PoligonoReg1.obtieneArea();
 }
 