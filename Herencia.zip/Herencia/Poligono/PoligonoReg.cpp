#include <iostream>
#include <algorithm>
#include <cmath>
#include "PoligonoReg.h"
#include "PoligonoIrreg.h"
#include "Coordenada.h"

using namespace std;

void PoligonoReg::addVertices(){
    double angle = 0;
    for(int i = 0; i < numVertices; i++)
    {
        double x = cos(angle * M_PI  / 180);
        double y = sin(angle * M_PI  / 180);
        PoligonoIrreg::addVertice(Coordenada(x,y,sqrt(x*x+y*y)),i);
        angle = angle + angulo;
    }
    
}
void PoligonoReg::obtieneArea(){
    Coordenada Coordena1 = PoligonoIrreg::getVertice(0);
    Coordenada Coordena2 = PoligonoIrreg::getVertice(1);
    double x = Coordena2.obtenerX() - Coordena1.obtenerX();
    double y = Coordena2.obtenerY() - Coordena1.obtenerY();
    double xmedio = (Coordena2.obtenerX() + Coordena1.obtenerX())/2;
    double ymedio = (Coordena2.obtenerY() + Coordena1.obtenerY())/2;
    double h = sqrt(xmedio*xmedio + ymedio*ymedio);
    double base = sqrt(x*x + y*y);
    cout << "Area: "numVertices*base*h/2<<endl;
}
